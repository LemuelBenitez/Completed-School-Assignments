package GamesAreLife;

public interface Connect4Player {
	public boolean isWinner();
	public void takeTurn();
	
	
}
