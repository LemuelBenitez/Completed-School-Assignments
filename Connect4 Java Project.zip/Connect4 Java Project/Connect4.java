package GamesAreLife;

public interface Connect4 {
	public void displayBoard();
	public void clearBoard();
	
	public boolean isEmpty();
	public boolean isFull();
	

}