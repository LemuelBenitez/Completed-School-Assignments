package gameInterface;

public interface Battle {

	public void run();
	
}