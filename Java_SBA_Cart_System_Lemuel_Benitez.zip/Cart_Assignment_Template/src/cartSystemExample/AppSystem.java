package cartSystemExample;


public class AppSystem extends TheSystem {


	public AppSystem(){
		super();
	}

	@Override
	public void display() {
		// Your code here
		//for(Map.Entry<String,Item> entry : itemCollection.entrySet()) {
		//System.out.println(entry.getKey() + " " + entry.getItemDesc().toString());
		//}
		getItemCollection().forEach((String, Item) -> System.out.println(String + " " + Item.getItemDesc() 
		+ " " + Item.getItemPrice() + " " + Item.getAvailableQuantity()));
      
	}

	@Override
	public Boolean add(Item item) {
		super.add(item);
		return true;
	}
	
}
