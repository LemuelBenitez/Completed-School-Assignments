package cartSystemExample;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public abstract class TheSystem {
	private HashMap<String, Item> itemCollection;

	TheSystem() {
        itemCollection = new HashMap<String, Item>();
        // Your code here
        	String filePath = "/Users/lemuelbenitez/Downloads/Cart_Assignment_Template/src/sample.txt";
        	try{
        		if(getClass().getSimpleName().equals("AppSystem")) {
        		File  file = new File(filePath);
        		Scanner loop = new Scanner(file);
        		while(loop.hasNextLine()){
        			Scanner read = new Scanner(loop.nextLine());
        			while(read.hasNext()) {
        			 String key = read.next();
        			 String s = read.next();
        			 Double k = Double.parseDouble(read.next());
        			 Integer j = Integer.valueOf(read.next());
        			 itemCollection.put(key,new Item(s,k,j));
        			}
        			read.close();
        		 }
        		loop.close();
        		}
        	}catch (FileNotFoundException e) {
        		e.printStackTrace();
        	}
	}

	public Boolean checkAvailability(Item item) {
		// Your code here
		if(item.getQuantity() >= item.getAvailableQuantity()) {
			System.out.println("System is unable to add " + item.getItemName() + " to the card. ");
		    return false;
	      }
			return true;
	}
	
	public Boolean add(Item item) {
		// Your code here
		try {
		if(item == null){
			return false;
		}
		
			for(Map.Entry<String,Item> entry : itemCollection.entrySet() ) {
		      if(item.getItemName().equals(entry.getKey())) {
		    	 entry.getValue().setAvailableQuantity(item.getAvailableQuantity() + entry.getValue().getAvailableQuantity());
			     entry.getValue().setQuantity(entry.getValue().getQuantity() + 1);
		    	 return true;
		}else if(!item.getItemName().equals(entry.getKey())) {
			itemCollection.put(item.getItemName(),new Item(item.getItemDesc(),item.getItemPrice(),item.getAvailableQuantity()));
			return true;
		}
		 }
		}catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	public Item remove(String itemName) {
		Item foundItem = null;  
		foundItem = itemCollection.get(itemName);
		itemCollection.entrySet().removeIf(entry -> itemName.contentEquals(entry.getKey()));
		return foundItem;

	}

	public abstract void display();
    
	public HashMap<String,Item> getItemCollection(){
		return this.itemCollection;
	}
	
	public void setItemCollection(HashMap<String, Item> itemCollection) {
		this.itemCollection = itemCollection;
	}
	
}
