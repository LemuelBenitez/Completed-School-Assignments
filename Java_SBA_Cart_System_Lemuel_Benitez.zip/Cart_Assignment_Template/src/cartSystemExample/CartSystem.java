package cartSystemExample;

import java.util.HashMap;
import java.util.Map;

public class CartSystem extends TheSystem {
	private HashMap<String, Item> itemCollection2;

	CartSystem() {
		itemCollection2 = new HashMap<String,Item>();
	}

	
	@Override
	public void display() {
		// Your code here
		double sub_total = 0;
		System.out.print("\n");
		if(itemCollection2.isEmpty()) {
			System.out.println("\nThere is nothing in the cart!\n");
		}else {
			double total =0;
			double tax = 0;
			//System.out.print("Something");
			for(Map.Entry<String, Item> entry: itemCollection2.entrySet()) {
				System.out.println("\nName: " + entry.getKey() + "  Quantity: " + entry.getValue().getQuantity());
				sub_total += entry.getValue().getItemPrice() * entry.getValue().getQuantity();
			}
			 tax= sub_total * 0.05;
			 total = sub_total + tax;
			 
			 System.out.println("\nSub-Total : " + sub_total + "\nTax : " + tax + "\nTotal : " + total);
			
		}
		
		
    }
	
	@Override
	public Boolean add(Item item) {	
				super.add(item);
               return true;
			}

	public HashMap<String, Item> getItemCollection2() {
		return itemCollection2;
	}


	public void setItemCollection2(String d, Item f) {
			itemCollection2.put(d,f); 
	}
	
	
	
}